var mymodule = angular.module("SampleApp",[]);

/**
 * Angular Controller
 */

mymodule.directive("fileInput", function($parse){
    return{
        link: function($scope, element, attrs){  
            element.on("change", function(event){  
                $scope.error = false
                $scope.error_msg = ''
                $scope.success = false
                $scope.success_msg = ''
                 var files = event.target.files;  
                 $parse(attrs.id).assign($scope, element[0].files)
                 $scope.$apply();  
                
            });  
       } 
    }
})


var upload_ctrler = mymodule.controller("uploadController", function ($scope, $http){
    $scope.error = false
    $scope.error_msg = ''
    $scope.success = false
    $scope.success_msg = ''
    $scope.files = {}

    

    /**
     * Trigger Upload Image
     * @param {int} page  
     */
    $scope.uploadImg = function(e){
       e.preventDefault()
        $scope.error = false
        $scope.error_msg = ''
        $scope.success = false
        $scope.success_msg = ''
       var fdata = new FormData()
        angular.forEach($scope.image_file, function(file){  
            fdata.append('image_file', file);  
        });  
       $http.post('upload_img.php', fdata, {
            transformRequest: angular.identity,  
            headers: {'Content-Type': undefined,'Process-Data': false }
       }).then(
        function success(response){
            
            if(response.status == 200){
                var data = response.data
                if(data.status == 'success' ){
                    $scope.success = true;
                    $scope.success_msg = 'Image has been uploaded successfully';
                }else{
                    $scope.error = true;
                    if(!!data.error){
                        $scope.error_msg = data.error;
                    }else{
                        $scope.error_msg = "Failed to upload image due to some errors.";
                    }
                }
                e.target.reset()
                $scope.getImages();
            }
        }, function error(error){
            console.error(error)
        }
       )
    }


    $scope.getImages = function(){
        $http({
            method:'GET',
            url:"getImages.php"
        }).then(
            function success(response){
                if(response.status == 200){
                    $scope.files = response.data
                }
            }, function error(error){
                console.error(error)
            }
        )
    }

    $scope.getImages();
    

})


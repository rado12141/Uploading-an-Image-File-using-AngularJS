<?php
//Upload files directory
$dir = "uploads/";

//Create Upload Directory If not existing yet
if(!is_dir($dir))
mkdir($dir);

$scandr = scandir($dir);
$files = [];
foreach($scandr as $file){
    if(in_array($file, ['.', '..']))
    continue;

    $files[] = ["path" =>$dir.$file, "name" =>$file];
}
echo json_encode($files);
?>
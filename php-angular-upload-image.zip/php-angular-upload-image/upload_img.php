<?php
if(isset($_FILES) && !empty($_FILES['image_file']['tmp_name'])){
    $file = $_FILES['image_file'];
    $file_path_part = pathinfo($file['name']);
    $filename = $file_path_part['filename'];
    $extension = $file_path_part['extension'];

    // Upload Directory
    $dir = 'uploads/';
    if(!is_dir($dir))
    mkdir($dir);

    // Iteration starting Value
    $i = 0;

    while(true){
        // Filename additional text
        $additional_txt = ($i>0) ? " ({$i})" : "";

        // Temporary new filename
        $tempname = $filename.$additional_txt.".".$extension;

        // Cheching Filename Duplicate
        if(is_file($dir.$tempname)){
            // If has duplicate
            $i++;
        }else{
            // Renew Filename
            $filename = $tempname;
            // break the loop
            break;
        }
    }

    $upload = move_uploaded_file($file['tmp_name'], $dir.$filename);
    if($upload){
        echo json_encode(['status' => 'success']);
    }else{
        echo json_encode(['status' => 'failed', 'error' => 'Failed to upload image.']);
    }
}else{
    echo json_encode(['status' => 'failed', 'error' => 'Request dont have an Image File.']);
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Angular JS Upload Image</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.8.3/angular.js" integrity="sha512-klc+qN5PPscoGxSzFpetVsCr9sryi2e2vHwZKq43FdFyhSAa7vAqog/Ifl8tzg/8mBZiG2MAKhyjH5oPJp65EA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <style>
        html, body{
            min-height:100%;
            width:100%;
        }
        tbody:empty:after{
            content:'No records found'
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
        <div class="container">
            <a class="navbar-brand" href="./">Angular JS Upload Image</a>
            <div>
                <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
            </div>
        </div>
    </nav>
    <div class="container-fluid px-5 my-3" ng-app="SampleApp" ng-controller="uploadController">
        <div class="col-lg-8 col-md-10 col-sm-12 mx-auto mb-3">
            <div class="card rounded-0 shadow mb-3">
                <div class="card-header">
                    <div class="card-title"><b>Uploading Image using AngularJS and PHP</b></div>
                </div>
                <div class="card-body">
                    <div class="container-fluid">
                        <div class="alert alert-danger mb-3 rounded-0" ng-show="error">{{error_msg}}</div>
                        <div class="alert alert-success mb-3 rounded-0" ng-show="success">{{success_msg}}</div>
                        
                        <form id="uploadForm" action="" ng-submit="uploadImg($event)">
                            <div class="mb-3">
                                <p class="text-muted">Browse the image you want to upload here</p>
                            </div>

                            <div class="mb-3">
                                <label for="image_file" class="form-label">Browse Image</label>
                                <input class="form-control form-control-sm" id="image_file" type="file" file-input accept="image/*" required>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-footer py-1">
                    <div class="text-center">
                        <button form="uploadForm" class="btn btn-primary rounded-pill col-lg-4 col-md-6 col-sm-8">Upload Image</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-8 col-sm-12 mx-auto">
            <div class="card rounded-0 shadow mb-3">
                <div class="card-header">
                    <div class="card-title"><b>Uploaded Images</b></div>
                </div>
                <div class="card-body">
                    <div class="container-fluid">
                        <div class="list-group">
                            <a href="{{file.path}}" ng-repeat="file in files" class="list-group-item list-group-item-action" target="_blank">
                                {{file.name}}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>